module.exports = {
	RecordDesc: {
		0: "长按开始录音",
		2: "向上滑动取消",
		3: "松开手取消",
	},
	RecordStatus: {
		SHOW: 0,
		HIDE: 1,
		HOLD: 2,
		SWIPE: 3,
		RELEASE: 4
	}
};
