<?php
return array(
	//'配置项'=>'配置值'
	'template'  =>  [
	    'layout_on'     =>  true,
	    'layout_name'   =>  'layout'
	]
);