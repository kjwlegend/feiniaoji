var Dispatcher = require("./Dispatcher");
module.exports = new Dispatcher();
